#------
#title: "Find relationship via genomic regions"
#author: xiaowei
#date: November 28, 2019
#Usedatabase:GREG-small-undirected
#Output: g1_rel or g1_rel_summary , (for task 1) a list of all DNA-DNA interactions between the following genomic regions (only the DNA-DNA interactions between them, not all interactions):
#        g2_rel_dna_dna ,(for task 2)   
#        g3_rel_dna_TF.LncRNA or summary_g3_rel_dna_TF.LncRNA: (for task 3) Report all the TFs or lncRNAs binding to each of the following genomic ranges:
#function: gene_from_node_detials
#          map_nodes_by_genomic_region
#          map_rel_of_both_genomic_region
#          map_rel_by_genomic_region

#------

#*******************************
#************Outline************
#*******************************
#1 connect neo4j with RNeo4j

#2 import data

######2.1 function1: get gene names from Details property of chromosome
######2.2 function2: find gene from genomic region in GREG
######2.3 map genes/ nodes

#3. a list of all DNA-DNA interactions between the following genomic regions 
#   (only the DNA-DNA interactions between them, not all interactions)

######3.1 function3: for map relationship during a list different genomic regions 
######3.2 find all DNA-DNA interactions relationship between the following genomic regions 
######    (only the DNA-DNA interactions between them, not all interactions)

#4 Report all the DNA-DNA interactions for each of the following genomic ranges and which 
#  bin(gene) is in the other side of the interaction (report all interactions; not only the ones between them).

######4.1 function4: get a nodes all bind relationships via define a genomic regions, relationship and celltype
######4.2 all the DNA-DNA interactions for each of the following genomic ranges and which bin(gene) is in the other side of the interaction

#5 Report all the TFs or lncRNAs binding to each of the following genomic ranges:



##########################################################################
#1 connect neo4j with RNeo4j
##########################################################################
library(RNeo4j)
graph = startGraph("http://localhost:7474/db/data/", username="neo4j", password="xiaowei")

##########################################################################
#2 import data
##########################################################################
g1  <-  read.csv("g1_20191127.csv", header = F)
names(g1) <- c("genename", "nodelabel", "start_number", "end_number" )

g2  <-  read.csv("g2_20191127.csv", header = F)
names(g2) <- c("rs","genename", "nodelabel", "start_number", "end_number" )

g3  <-  read.csv("g3_20191127.csv", header = F)
names(g3) <- c("rs","genename", "nodelabel", "start_number", "end_number" )

#==========================================================================
#	#2.1 function1: get gene names from Details property of chromosome
#==========================================================================
#Because Details property in chromosome have many information about genes.
# Then I make a function to get gene names from Details property of chromosome
#
#input:
#details: the property in chromosome node
#re: default as 'string', means the result is a string, 'vector' means the result is a vector included all gene names.

gene_from_node_Detials <- function(details, re = "string"){
  
  details2 = strsplit(details, fixed = TRUE,';')[[1]]
  details3 = details2[grep("gene_name", details2, fixed = TRUE)]
  details4 = unique( gsub("( )gene_name( )", "", details3, fixed = F) )
  details5 = paste0(details4,  collapse = "; " )
  
  if (re == 'string'){  return (details5)}
  if (re == 'vector'){ return (details4)}
}
#==========================================================================
#	#2.2 function2: find gene from genomic region in GREG
#==========================================================================
#This function help you get the node about your input genomic region
#input:
#A data.frame  likes g1 object which included nodellabel, start_number and end_number columns
#values:
#A data.frame  included all nodes' information about your input data

map_nodes_by_genomic_region <- function(g1){
  
  nodelist <- list()
  for (i in 1:nrow(g1)){
    label = g1$nodelabel[i]
    start_number = g1$start_number[i]
    end_number = g1$end_number[i]
    query = paste0("MATCH(A:",label, ")
                  where toInt(A.Start) <= ",end_number, " and toInt(A.End) >= ", start_number,
                   "
                 RETURN id(A) AS NodeID, 
                      labels(A) AS NodeLabel,
                      properties(A) AS properties
    ")
    chr_node <- cypher(graph, query)
    library(neo4r)
    nodesdetails <- neo4r::unnest_nodes(chr_node, what = "properties")
    
    nodesdetails$gene_name <- unlist(lapply(nodesdetails$Details, FUN = gene_from_node_Detials))
    
    nodelist[[i]] <- nodesdetails
  }
  
  names(nodelist) <- g1$genename
  
  return(nodelist)
  
}

#==========================================================================
#	#2.3 map genes/ nodes
#==========================================================================
#-------------------
g1_nodes <- map_nodes_by_genomic_region(g1)
g2_nodes <- map_nodes_by_genomic_region(g2)
g3_nodes <- map_nodes_by_genomic_region(g3)

##########################################################################
#3. a list of all DNA-DNA interactions between the following genomic regions 
#   (only the DNA-DNA interactions between them, not all interactions)
##########################################################################
#==========================================================================
#	#3.1 function3: for map relationship during a list different genomic regions 
#==========================================================================
#This function help you get the relationship between genomic regions in the same input table.
#The relationship is (A)-[r1:Inclusion]->(B)-[r2:Interaction]->(C)<-[r3:Inclusion]-(D)
#So A and D nodes are chromosome nodes In GREG, B and C nodes are chromosome Range nodes.
#input:
#g1:  A data.frame  likes g1 object which included nodellabel, start_number and end_number columns
#celltype: You can choose celltype one of "'MCF7'", "'K562'", "'IMR90'", "'A549'", "'HELA'", "'H1ESC'", "'IPS6.9'" and "'IPS19.11'"
#rel: Only suppost "Interaction"
#Values:
#A data.frame  which included all relationships information above-mentioned. colnames are A_label,A_Name, B_label, B_Start, B_End, C_label,
#              C_Start, C_End, D_label and D_Name

map_rel_of_both_genomic_region = function(g1, rel = "Interaction",  celltype = "'IMR90'"){
  
  g1_nodes <- map_nodes_by_genomic_region(g1)
  nodelist <- data.frame()
  for (i in 1:length(g1_nodes)){nodelist <- rbind(nodelist, g1_nodes[[i]])}
  
  query = paste0(" MATCH (A)-[r1:Inclusion]->(B)-[r2:", rel, "]->(C)<-[r3:Inclusion]-(D)
                    where id(A) in {nodelist} and id(D) in {nodelist} and r2.CellType = ",celltype,
                    "
                    RETURN labels(A) AS A_label, 
                           A.Name AS A_Name,
                            
                           labels(B) AS B_label,
                           B.Start AS B_Start,
                           B.End AS B_End,
                           
                           labels(C) AS C_label,
                           C.Start AS C_Start,
                           C.End AS C_End,
                           
                           labels(D) AS D_label,
                           D.Name AS D_Name,
                           
                           A.Details AS A_Details,
                           D.Details AS D_Details
                 
  ")
  
  ADRelationship <- cypher(graph, query, nodelist = unlist(nodelist$NodeID))
  
  return(ADRelationship)
}

#==========================================================================
#	#3.2 find all DNA-DNA interactions relationship between the following genomic regions 
#      (only the DNA-DNA interactions between them, not all interactions)
#==========================================================================
#------------------------------
g1_rel <- map_rel_of_both_genomic_region(g1)

#In order to know what genes are in A and D nodes, run the codes likes as following：
g1_rel$A_gene_name <- unlist(lapply(g1_rel$A_Details, FUN = gene_from_node_Detials))
g1_rel$D_gene_name <- unlist(lapply(g1_rel$D_Details, FUN = gene_from_node_Detials))

#In order to easily see the result, we put key information of relationship in a new dataframe. 
g1_rel_summary <- g1_rel
g1_rel_summary$A_node <- paste0(g1_rel$A_label,': ', g1_rel$A_Name)
g1_rel_summary$B_node <- paste0(g1_rel$B_label,': { Start: ', g1_rel$B_Start, ' End: ', g1_rel$B_End, '}')
g1_rel_summary$C_node <- paste0(g1_rel$C_label,': { Start: ', g1_rel$C_Start, ' End: ', g1_rel$C_End, '}')
g1_rel_summary$D_node <- paste0(g1_rel$D_label,': ', g1_rel$D_Name)
g1_rel_summary <- g1_rel_summary[, c("A_node", "B_node", "C_node", "D_node", "A_gene_name", "D_gene_name")]

##########################################################################
#4 Report all the DNA-DNA interactions for each of the following genomic ranges and which bin(gene)
#  is in the other side of the interaction (report all interactions; not only the ones between them).
##########################################################################

#==========================================================================
#	#4.1 function4: get a nodes all bind relationships via define a genomic regions, relationship and celltype
#==========================================================================
# In this function, we can get interaction or bind relationships with a same nodes in different cell.
#When you choose Interation relationship, the path is (A)-[r1:Inclusion]->(B)-[r2:Interaction]-(C)<-[r3:Inclusion]-(D)
#In this path relationship, A and D nodes are chromosome nodes In GREG, B and C nodes are chromosome Range nodes.
#When you choose Bind relationship, the path is (A)-[r:Bind]-(B)
#In this path relationship, A nodes are chromosome nodes In GREG,but B nodes are TF or LncRNA nodes.
#       B_label, B_Start, B_End, C_label,C_Start, C_End, D_label and D_Name
#input:
#g1:  A data.frame  likes g1 object which included nodellabel, start_number and end_number columns
#celltype: You can choose celltype one of "'MCF7'", "'K562'", "'IMR90'", "'A549'", "'HELA'", "'H1ESC'", "'IPS6.9'" and "'IPS19.11'"
#rel: default as "Interaction", you can choose "Interaction" or "Bind"
#Values:
#results is a list about your input data, and each genename in your input data as a inside list which has two data.frame. 
#                   one is ADRelationship object, 
#                   the other is ADRelationship_summary object, which sum of ADRelationship object.




map_rel_by_genomic_region = function(g1, rel = "Interaction", celltype = "'IMR90'"){
  
  dd_inter <- list()
  for (i in 1:nrow(g1)){
    label = g1$nodelabel[i]
    start_number = g1$start_number[i]
    end_number = g1$end_number[i]
    #----------------------------------------------------------------------------------------------------------------------------------------
    # When relationship is Interaction
    #----------------------------------------------------------------------------------------------------------------------------------------    
    if (rel == "Interaction"){

        query = paste0(" MATCH(A:", label,")-[r1:Inclusion]->(B)-[r2:", rel, "]->(C)<-[r3:Inclusion]-(D)
                       where toInt(A.Start) <= ",end_number, " and toInt(A.End) >= ", start_number, " and r2.CellType =",celltype,
                       "
                        RETURN labels(A) AS A_label, 
                               A.Name AS A_Name,
                                
                               labels(B) AS B_label,
                               B.Start AS B_Start,
                               B.End AS B_End,
                               
                               labels(C) AS C_label,
                               C.Start AS C_Start,
                               C.End AS C_End,
                               
                               labels(D) AS D_label,
                               D.Name AS D_Name,
                               
                               A.Details AS A_Details,
                               D.Details AS D_Details
                     
      ")
        
        
        ADRelationship <- cypher(graph, query)
        
        if ( is.null(ADRelationship) ){ 
          dd_inter[[i]] = paste0("No_", rel,"_relationship")
        }else{
          
          ADRelationship$A_gene_name <- unlist(lapply(ADRelationship$A_Details, FUN = gene_from_node_Detials))
          ADRelationship$D_gene_name <- unlist(lapply(ADRelationship$D_Details, FUN = gene_from_node_Detials))
          ADRelationship_summary <- ADRelationship
          ADRelationship_summary$A_node <- paste0(ADRelationship$A_label,': ', ADRelationship$A_Name)
          ADRelationship_summary$B_node <- paste0(ADRelationship$B_label,': { Start: ', ADRelationship$B_Start, ' End: ', ADRelationship$B_End, '}')
          ADRelationship_summary$C_node <- paste0(ADRelationship$C_label,': { Start: ', ADRelationship$C_Start, ' End: ', ADRelationship$C_End, '}')
          ADRelationship_summary$D_node <- paste0(ADRelationship$D_label,': ', ADRelationship$D_Name)
          ADRelationship_summary <- ADRelationship_summary[, c("A_node", "B_node", "C_node", "D_node", "A_gene_name", "D_gene_name")]
          
          dd_inter[[i]] = list(ADRelationship = ADRelationship, ADRelationship_summary = ADRelationship_summary)
        }
    }
    #----------------------------------------------------------------------------------------------------------------------------------------
    # When relationship is bind
    #----------------------------------------------------------------------------------------------------------------------------------------
    if (rel == 'Bind'){
      query = paste0("MATCH(A:", label,")-[r:",  rel,  "]-(B)
          where toInt(A.Start) <= ",end_number, " and toInt(A.End) >= ", start_number, " and r.CellType =",celltype, 
                     " 
           RETURN labels(A) AS A_label, 
                               A.Name AS A_Name,
                               
                               labels(B) AS B_label,
                               B.Name AS B_Name,
                               
                               A.Details AS A_Details
  ")
      ABRelationship <- cypher(graph, query)
      if ( is.null(ABRelationship) ){ 
        dd_inter[[i]] = paste0("No_", rel,"_relationship")
      }else{
        
        ABRelationship$A_gene_name <- unlist(lapply(ABRelationship$A_Details, FUN = gene_from_node_Detials))
        ABRelationship_summary <- ABRelationship
        ABRelationship_summary$A_node <- paste0(ABRelationship$A_label,': ', ABRelationship$A_Name)
        ABRelationship_summary$B_node <- paste0(ABRelationship$B_label,': ', ABRelationship$B_Name)
        ABRelationship_summary <- ABRelationship_summary[, c("A_node", "B_node","A_gene_name")]
        
        dd_inter[[i]] = list(ABRelationship = ABRelationship, ABRelationship_summary = ABRelationship_summary)
      }
      
      
      
    }
  }
  
    
  names(dd_inter) <- g1$genename
  
  return(dd_inter)
  
}

#==========================================================================
#	#4.2 all the DNA-DNA interactions for each of the following genomic ranges and 
#      which bin(gene) is in the other side of the interaction
#==========================================================================
#-------------------
g2_rel_dna_dna <- map_rel_by_genomic_region(g2)

##########################################################################
#5 Report all the TFs or lncRNAs binding to each of the following genomic ranges:
##########################################################################
g3_rel_dna_TF.LncRNA <- map_rel_by_genomic_region(g3, rel = "Bind")

#to sum the g3_rel_data_TF.LncRNA as a table
summary_g3_rel_dna_TF.LncRNA <- data.frame()
for (i in 1:length(g3_rel_dna_TF.LncRNA)){
  summary_g3_rel_dna_TF.LncRNA[i,1] <- names(g3_rel_dna_TF.LncRNA)[i]
  if (is.character(g3_rel_dna_TF.LncRNA[[i]])){
    summary_g3_rel_dna_TF.LncRNA[i,2] = 0
    summary_g3_rel_dna_TF.LncRNA[i,3] = 0}
  
  else{
    rel_dna_TF.LncRNA <- g3_rel_dna_TF.LncRNA[[i]]$ABRelationship
    TF = rel_dna_TF.LncRNA$B_Name[which(rel_dna_TF.LncRNA$B_label == "TF")]
    LncRNA = rel_dna_TF.LncRNA$B_Name[which(rel_dna_TF.LncRNA$B_label == "LncRNA")]
    
    if(length(TF) == 0 ){summary_g3_rel_dna_TF.LncRNA[i,2] = 0}
    else{ summary_g3_rel_dna_TF.LncRNA[i,2] <- paste0(TF, collapse = "; ")}
    if(length(LncRNA) ==0){summary_g3_rel_dna_TF.LncRNA[i,3] <- 0}
    else{summary_g3_rel_dna_TF.LncRNA[i,3] <- paste0(LncRNA, collapse = "; ")}
  }
}
names(summary_g3_rel_dna_TF.LncRNA) <- c("inputgene", "TF", "LncRNA")

#=================================================
save(g1,g2, g3, g1_nodes ,g2_nodes, g3_nodes , g1_rel, g1_rel_summary, g2_rel_dna_dna ,  g3_rel_dna_TF.LncRNA, summary_g3_rel_dna_TF.LncRNA, file = "Find_relationship_via_genomic_region2.RData")


#Question: Why I didn't get the TF/LncRNA about CHRNA3 in the g3 table
#Answer: Because I used the first row about CHRNA3, I do not get any relationship
    query = "match (A:chr15)-[r:Bind]-(B)
    where toInt(A.Start) <= 78601997 and toInt(A.End) >= 78601997 and r.CellType = 'IMR90'
    return A.Name, r.CellType, B.Name"
    cypher(graph, query)
    #If I used CHRNA3 in g1 table
    query = "match (A:chr15)-[r:Bind]-(B)
    where toInt(A.Start) <= 78621295 and toInt(A.End) >= 78593052 and r.CellType = 'IMR90'
    return A.Name, r.CellType, B.Name"
    cypher(graph, query)
#So, the problem is the genomic region. 