#------
#title: "Find Genes are binding to LMNB1 Transcription Factor  "
#author: xiaowei
#date: November 29, 2019
#Usedatabase:GREG-small-undirected
#Output:
#        #1. Please find all the bins that bind to the LMNB1 Transcription Factor.
#         B_nodes
#        #2. Find how many of those bins have genes inside and how many bins are empty (no genes).
#        B_nodes1_have_gene, _________ 325146 nodes have genes
#        B_nodes1_no_gene , __________ 162809 nodes not have genes
#        B_nodes2_no_Details, _________162809 nodes not have Details property
#        #3. Send me the list of genes.
#        B_nodes1_genes ___________ 38648 genes are binding LMNB1
#        chr_nodes_genes __________ See what genes are binding LMNB1 in each chromosome

#function: gene_from_node_detials



#*******************************
#************Outline************
#*******************************
#------
#1 connect neo4j with RNeo4j
#2 function1: get gene names from Details property of chromosome
#3 Please find all the bins that bind to the LMNB1 Transcription Factor.
#4. Find how many of those bins have genes inside and how many bins are empty (no genes).
#########		#Find those nodes have details property
#########		#Find out those nodes have genes
#########		#those nodes not have genes
#########		#Those nodes not have details property
#5. Send me the list of genes.
#########		#Get a list of those genes
#########		#For see what genes bind LMNB1 in each chromosome


##########################################################################
#1 connect neo4j with RNeo4j
##########################################################################
library(RNeo4j)
graph = startGraph("http://localhost:7474/db/data/", username="neo4j", password="xiaowei")

#==========================================================================
#2 function1: get gene names from Details property of chromosome
#==========================================================================
#Because Details property in chromosome have many information about genes.
# Then I make a function to get gene names from Details property of chromosome
#
#input:
#details: the property in chromosome node
#re: default as 'string', means the result is a string, 'vector' means the result is a vector included all gene names.

gene_from_node_Detials <- function(details, re = "string"){
  
  details2 = strsplit(details, fixed = TRUE,';')[[1]]
  details3 = details2[grep("gene_name", details2, fixed = TRUE)]
  details4 = unique( gsub("( )gene_name( )", "", details3, fixed = F) )
  details5 = paste0(details4,  collapse = "; " )
  
  if (re == 'string'){  return (details5)}
  if (re == 'vector'){ return (details4)}
}


##########################################################################
#3 Please find all the bins that bind to the LMNB1 Transcription Factor.
##########################################################################

query = "match (A:TF{Name:'LMNB1'})-[r:Bind]->(B)
        return labels(B) as B_label,
                B.Name AS B_Name,
                properties(B) AS properties "
B_nodes <- cypher(graph, query)

#Do not run, it will take long time.
#B_nodes1 <- neo4r::unnest_nodes(B_nodes, what = "properties")

##########################################################################
#4. Find how many of those bins have genes inside and how many bins are empty (no genes).
##########################################################################

#=====================================================
#Find those nodes have details property
#=====================================================
query = "match (A:TF{Name:'LMNB1'})-[r:Bind]->(B)
        return labels(B) as B_label,
                B.Name AS B_Name,
                B.Details AS B_Details "
B_nodes1 <- cypher(graph, query)
B_nodes1$geneName <- unlist(lapply(B_nodes1$B_Details, FUN = gene_from_node_Detials))
#=====================================================
#Find out those nodes have genes
#=====================================================
B_nodes1_have_gene <- B_nodes1[which(B_nodes1$geneName !="" ),]

#=====================================================
#those nodes not have genes
#=====================================================
B_nodes1_no_gene <- B_nodes1[which(B_nodes1$geneName =="" ),]

#=====================================================
#Those nodes not have details property
#=====================================================
query = "match (A:TF{Name:'LMNB1'})-[r:Bind]->(B)
        where not exists(B.Details)
        return labels(B) as B_label,
                B.Name AS B_Name "
B_nodes2_no_Details <- cypher(graph, query)

##########################################################################
#5. Send me the list of genes.
##########################################################################
#===================================
#Get a list of those genes
#===================================
#Now, make a string contains all nodes genes (also included duplicated genes)
B_nodes1_genes <- paste0(B_nodes1_have_gene$geneName, collapse = "; ")

#split the strings and remove duplicated genes
B_nodes1_genes <- unique(strsplit(B_nodes1_genes, "; ", fixed = TRUE)[[1]])
length(B_nodes1_genes) #38648

#=======================================================
#For see what genes bind LMNB1 in each chromosome
#======================================================
#Let us how many nodes are in each choromosome
table(B_nodes1_have_gene$B_label)
B_nodes1_genes_chr <- split(B_nodes1_have_gene, B_nodes1_have_gene$B_label)

chr_nodes_genes = list()
for (i in 1:length(B_nodes1_genes_chr)){
  nodes_genes <-  B_nodes1_genes_chr[[i]]
  
  chr_genes <- paste0(nodes_genes$geneName, collapse = "; ")
  chr_genes <- unique(strsplit(chr_genes, "; ", fixed = TRUE)[[1]])
  
  chr_nodes_genes[[i]] <- chr_genes
  names(chr_nodes_genes)[i] <- names(B_nodes1_genes_chr)[i]
}
##############
#save
##############
save(B_nodes,B_nodes1,B_nodes1_genes, B_nodes1_genes_chr,B_nodes1_have_gene,B_nodes1_no_gene,B_nodes2_no_Details, chr_nodes_genes,
     file = "Find_Genes_bind_to_LMNB1.RData"
)
