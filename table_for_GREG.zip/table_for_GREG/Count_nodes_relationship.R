#========================================
#Connect neo4j
#========================================
library(RNeo4j)
graph = startGraph("http://localhost:7474/db/data/", username="neo4j", password="xiaowei")

#========================================
# count nodes
#========================================
query = "MATCH (n) RETURN distinct labels(n) as label, count(labels(n)) as count"
labels <- cypher(graph,query) 
labels

query =  "MATCH (n) RETURN DISTINCT labels(n), count(*) AS count"
labels <- cypher(graph,query) 
labels

rownames(labels) <- labels$label
#TF数量
TF <- labels["TF",]
TF
TF1 <- cypher(graph, query = "MATCH(n:TF) RETURN count(distinct n) AS count")
TF1

#lncRNA数量
LncRNA <- labels["LncRNA",]
LncRNA

LncRNA1 <- cypher(graph, query = "MATCH(n:LncRNA) RETURN count(distinct n) AS count") 
LncRNA1

#chr数量
allBin <- labels[c(paste0("chr",1:22),'chrX', 'chrY'),]
allBin
number_allBin <- sum(allBin$count)
number_allBin


#chr_range数量
chr_range <- labels[c(paste0("chr", 1:22, "_Range"), "chrX_Range","chrY_Range"), ]  
chr_range
number_chr_range <- sum(chr_range$count)
number_chr_range
#=================================================
# Count relathionship
#==================================================
############################
#Mathod 1 ##################
############################
#TF-TF
query = "match(A:TF)-[r:Interaction]->(B:TF)
return count(distinct(r)) as count"
number_TF_TF <- cypher(graph, query)
number_TF_TF

#TF-Bind-chr
query = "match(A:TF)-[r:Bind]->(B)
return count(distinct(r)) as count"
number_TF_chr <- cypher(graph, query)
number_TF_chr

#chr_Range-chr_Range
query = "match(A)-[r:Interaction]->(B)
return count(distinct(r)) as count"
all_interaction <- cypher(graph, query)
number_chrRange_chrRange <- all_interaction - number_TF_TF
number_chrRange_chrRange

#LncRNA-Bind-chr
query = "match(A:LncRNA)-[r:Bind]->(B)
return count(distinct(r)) as count"
number_LncRNA_chr <- cypher(graph, query)
number_LncRNA_chr
############################
#Mathod 1 ##################
############################
#Count relationships between two kinds of labels
#========================================================================
query <- "MATCH (A)-[r]->(B) 
return labels(A) AS A, 
        type(r) AS relationshipType, 
        labels(B) AS B ,
        count(distinct r) AS count"
rel_details <- cypher(graph, query)


#-----Bind relationship-----
BindRel <- rel_details[which(rel_details$relationshipType == "Bind"), ] 

#-----TF Binding relationship-----
BindRel_TF <- BindRel[which(BindRel$A == "TF"),]
BindRel_TFSUM <- sum(BindRel_TF$count)
BindRel_TFSUM

#-------LncRNA Bind relationship---------------
BindRel_LncRNA <- BindRel[which(BindRel$A == "LncRNA"),]
BindRel_LncRNASUM <- sum(BindRel_LncRNA$count)
BindRel_LncRNASUM

#-----Interaction relationship --------------
InteractionRel <- rel_details[rel_details$relationshipType =="Interaction",]


#---------TF - TF interaction relationships-------------
TFInteractionRel <- InteractionRel[InteractionRel$A == "TF",]
TFInteractionRelSUM <- sum(TFInteractionRel$count)
TFInteractionRelSUM

#--------chr_Range - chr_Range raltionships-------------
chr_RangeRel <- InteractionRel[InteractionRel$A != "TF",]
chr_RangeRelSUM <- sum(chr_RangeRel$count)
chr_RangeRelSUM
