#========================================
#Connect neo4j
#========================================
library(RNeo4j)
graph = startGraph("http://localhost:7474/db/data/", username="neo4j", password="xiaowei")
#========================================================================
#1.1 Get hubs for chr12 (a hub is degree > 50)
#========================================================================
#Use the whole database graph to make degree algorithm, and return chr12 nodes
query = "
CALL algo.degree.stream(
                        'MATCH (allnodes) return allnodes',
                        'Interaction | Inclution | Bind',
                        {direction: 'both'})
YIELD nodeId, score
with nodeId, score
MATCH (chr12:chr12)
where id(chr12) = nodeId and score > 50
RETURN chr12.Name AS Name, score as degree
ORDER By score DESC
"
chr12_hubs <- cypher(graph, query)

#========================================================================
#1.2 plot frequency and distribution of degree for chr12 hubs 
#========================================================================
ggplot(chr12_hubs, aes(x=degree))+ 
  geom_histogram(binwidth=30,colour="black", fill = "lightblue")+ #distribution plot
  #geom_vline(aes(xintercept=mean(degree, na.rm=T)), color="red", linetype="dashed", size=1)+   #mean
  labs(x="degree",y = "number of DNA bins")+
  scale_x_continuous(breaks = seq(0,700, by = 100)) + 
  theme(axis.text.x = element_text(vjust = 0.5, hjust = 1, angle = 90 ),
        plot.title = element_text(face ="bold" ,hjust = 0.5))


##########################################################################
#2. List of hubs for TF (a hub is a node with a high degree)
##########################################################################

#========================================================================
#2.1 get hubs for TF (a hub is degree > 50)
#========================================================================

#Use the whole database graph to make degree algorithm, and return TF nodes
query = "
CALL algo.degree.stream(
                        'MATCH (allnodes) return allnodes',
                        'Interaction | Inclution | Bind',
                        {direction: 'both'})
YIELD nodeId, score
with nodeId, score
MATCH (TF:TF)
where id(TF) = nodeId and score > 50
RETURN TF.Name AS Name, score as degree
ORDER By score DESC
"
TF_hubs <- cypher(graph, query)

#========================================================================
#2.2 plot frequency of degree for TF hubs 
#========================================================================
library(ggplot2)
ggplot(TF_hubs, aes(x=degree))+ 
  geom_histogram(binwidth=300,colour="black", fill = "lightblue")+ #distribution plot
  #geom_vline(aes(xintercept=mean(degree, na.rm=T)), color="red", linetype="dashed", size=1)+   #mean
  #ggtitle("Ferquency of degree in TF") +
  labs(x="degree",y = "number of Proteins bins")+
  scale_x_continuous(breaks = seq(0,15000, by = 1000)) + 
  theme(axis.text.x = element_text(vjust = 0.5, hjust = 1, angle = 90 ),
        plot.title = element_text(face ="bold" ,hjust = 0.5))
